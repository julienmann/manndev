# Lake of Bays Sailing Club website rebuild

A mobile-first, conversion-focused static site. The single primary job of the
site is getting parents to **register kids for junior sailing**. Built to the
`lbsc.ca` rebuild brief.

## How it's put together

Plain static HTML/CSS/JS with a tiny Node build step so the shared chrome
(header, nav, drawer, footer) lives in **one** place and is inlined into every
page. DRY to edit, plain static HTML to ship (good for SEO, works without JS).

```
build.mjs              ← nav model + document chrome; assembles the pages
src/pages/<slug>.html  ← the editable content of each page (this is what you edit)
assets/css/tokens.css  ← design tokens (colours, type scale)
assets/css/main.css    ← layout + components
assets/js/app.js       ← drawer, program finder, sticky CTA, analytics stub
assets/img/hero.svg    ← placeholder illustration (swap for real club photos)
<slug>.html            ← BUILD OUTPUT. Do not edit by hand
_redirects             ← 301 map for the 17 legacy URLs
```

## Editing

```bash
node build.mjs          # rebuild all pages after editing anything in src/ or build.mjs
```

- **Change a price / date:** edit the table in `src/pages/junior-sailing.html`, rerun `node build.mjs`.
- **Add a nav item:** edit the `NAV` array in `build.mjs`.
- **Add a page:** add a fragment in `src/pages/` and an entry to the `PAGES` array in `build.mjs`.

## Before launch: verify with the club (from the brief, §9)

- [x] Instructor count resolved: **19** (Summer 2026 roster). Real names, roles, verbatim bios and photos are in `src/pages/instructors.html` / `assets/img/instructors/`, pulled from the live site. Re-verify the roster each spring.
- [ ] 2026/2027 pricing and exact season dates
- [ ] Photo consent: the real photos in `assets/img/photos/` were pulled from the current live lbsc.ca; confirm written consent is on file for any identifiable minors before relaunch. The homepage hero is a custom illustration (`hero.svg`), kept per request.
- [x] Testimonials resolved: fabricated quotes replaced with a real, verifiable trust signal (5.0 Google rating, linked to the listing). Written review text wasn't publicly accessible to pull quotes from; swap in real ones later if the board collects any.
- [ ] Capital Campaign target / raised / funded projects (donate page)
- [ ] Wire the contact + newsletter forms to a provider
- [ ] Link the real Bylaws / Privacy / Safe Sport / Financials PDFs (governance page)
- [ ] Confirm the Sail Canada donation URL and the "LBSC Capital Campaign" dropdown step
- [ ] Add privacy-respecting analytics (Plausible/Fathom). `data-track` hooks are already on every CTA

## Not yet done vs. the brief

This is a complete, runnable static prototype of all 15 pages with real copy,
the design system, program finder, price transparency, sticky mobile CTA, and
seasonality-ready structure. Deferred (needs club data or a CMS/host decision):
live "This Week" newsletter feed, real Instagram embed, Checklick availability
badges, the off-season config toggle wired to a date, and JSON-LD `Course`/`Event`
blocks beyond the homepage `SportsClub`.
