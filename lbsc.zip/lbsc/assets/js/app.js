/* LBSC: progressive enhancement. Everything works without JS; this makes it nicer. */
(function () {
  'use strict';

  /* ---- Mobile drawer ---- */
  var toggle = document.querySelector('.nav-toggle');
  var drawer = document.getElementById('drawer');
  if (toggle && drawer) {
    var open = function () {
      drawer.dataset.open = 'true';
      document.body.classList.add('no-scroll');
      toggle.setAttribute('aria-expanded', 'true');
      var c = drawer.querySelector('.drawer-close'); if (c) c.focus();
    };
    var close = function () {
      drawer.dataset.open = 'false';
      document.body.classList.remove('no-scroll');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    };
    toggle.addEventListener('click', open);
    var closeBtn = drawer.querySelector('.drawer-close');
    if (closeBtn) closeBtn.addEventListener('click', close);
    drawer.addEventListener('click', function (e) {
      if (e.target.closest('a')) close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && drawer.dataset.open === 'true') close();
    });
  }

  /* ---- Sticky register bar (Home + Junior Programs) ---- */
  var sticky = document.querySelector('.sticky-cta');
  var heroEl = document.querySelector('[data-hero-sentinel]');
  if (sticky && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      sticky.dataset.show = entries[0].isIntersecting ? 'false' : 'true';
    }, { rootMargin: '-40% 0px 0px 0px' });
    if (heroEl) io.observe(heroEl); else sticky.dataset.show = 'true';
  } else if (sticky) {
    sticky.dataset.show = 'true';
  }

  /* ---- Program finder ---- */
  var finder = document.getElementById('finder');
  if (finder) {
    // program data: [name, ages, hours, learn, slug]
    var PROGRAMS = {
      youngsalts: { name: 'Young Salts', ages: 'Ages 7+', hours: 'AM, PM or full day', learn: 'An introductory sailing program covering Sail Canada\'s Wet Feet content.' },
      cansail1:   { name: 'CANSail 1', ages: 'Ages 8+', hours: 'AM, PM or full day', learn: 'Introduces sailors to the basic concepts and skill set needed to sail a boat.' },
      cansail2:   { name: 'CANSail 2', ages: 'Completed CANSail 1', hours: 'AM, PM or full day', learn: 'Sailors leave comfortable with boat rigging, control, knots and boat parts.' },
      cansail3:   { name: 'CANSail 3', ages: 'Completed CANSail 2', hours: 'AM, PM or full day (full-day Wednesdays)', learn: 'An intermediate course focused on directional changes, upwind and downwind sailing, plus an introduction to trapeze.' },
      cansail4:   { name: 'CANSail 4', ages: 'Completed CANSail 3', hours: 'Full day', learn: 'An advanced course that perfects earlier skills, introduces spinnaker work and basic racing rules. Local regattas available.' },
      cansail5:   { name: 'CANSail 5', ages: 'Completed CANSail 4', hours: 'Full day', learn: 'An advanced course with a focus on speed, introducing competitive sailing at a local level with racing tactics and skills.' },
      cansail6:   { name: 'CANSail 6', ages: 'Completed CANSail 5', hours: 'Full day', learn: 'The top level, focused on competition for sailors taking their racing to a provincial level.' },
      teen:       { name: 'Teen Sailing', ages: 'Ages 13+', hours: 'AM, PM or full day', learn: 'For sailors 13 and older who are new to sailing, or simply want to sail for fun with friends. Testing for CANSail 1 &amp; 2 on request.' }
    };
    var RACE_TEAM = {
      name: 'Race Teams',
      learn: 'Junior and senior Race Teams train and travel all season for CANSail 4–6 and Opti racers, competing at regattas like CORK and the Hans Fogh Regatta.'
    };
    // decision matrix: only the "never sailed" entry point depends on age.
    // every completed CANSail level moves a sailor up to the next one, regardless of age.
    var NEVER_SAILED_BY_AGE = { '7': 'youngsalts', '8-10': 'cansail1', '11-12': 'cansail1', '13+': 'teen' };
    var NEXT_LEVEL = {
      youngsalts: 'cansail1',
      cansail1: 'cansail2',
      cansail2: 'cansail3',
      cansail3: 'cansail4',
      cansail4: 'cansail5',
      cansail5: 'cansail6',
      cansail6: null // already at the top level
    };
    // CANSail 4 and above: also suggest the Race Teams
    var SUGGESTS_RACE_TEAM = { cansail4: true, cansail5: true, cansail6: true };

    var out = finder.querySelector('.finder-result');
    var update = function () {
      var age = finder.querySelector('input[name="age"]:checked');
      var exp = finder.querySelector('input[name="exp"]:checked');
      if (!age || !exp) return;
      var key = exp.value === 'never' ? NEVER_SAILED_BY_AGE[age.value] : NEXT_LEVEL[exp.value];
      var p = key ? PROGRAMS[key] : null;
      var showRaceTeam = !!SUGGESTS_RACE_TEAM[exp.value];

      var html = '';
      if (p) {
        html +=
          '<div class="card">' +
            '<span class="eyebrow">Recommended for your sailor</span>' +
            '<h3 style="margin-top:.3rem">' + p.name + '</h3>' +
            '<div class="result-meta">' +
              '<span class="badge badge--info">' + p.ages + '</span>' +
              '<span class="badge badge--info">' + p.hours + '</span>' +
            '</div>' +
            '<p>' + p.learn + '</p>' +
            '<div class="btn-row mt-3">' +
              '<a class="btn btn--primary" href="https://lakeofbayssailingclub.checklick.com/" target="_blank" rel="noopener" data-track="register" data-source="finder">See pricing &amp; register on Checklick</a>' +
              '<a class="btn btn--secondary" href="junior-sailing.html#ladder">See all programs</a>' +
            '</div>' +
          '</div>';
      }
      if (showRaceTeam) {
        html +=
          '<div class="card mt-2">' +
            '<span class="eyebrow">Ready to race</span>' +
            '<h3 style="margin-top:.3rem">' + RACE_TEAM.name + '</h3>' +
            '<p>' + RACE_TEAM.learn + '</p>' +
            '<div class="btn-row mt-3">' +
              '<a class="btn btn--secondary" href="race-teams.html" data-track="racehub" data-source="finder">See Race Teams</a>' +
            '</div>' +
          '</div>';
      }
      out.innerHTML = html;
      out.hidden = !html;
    };
    finder.addEventListener('change', update);
  }

  /* ---- Lightweight event tracking (console stub; swap for Plausible/Fathom) ---- */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-track]');
    if (!t) return;
    var name = t.getAttribute('data-track');
    var source = t.getAttribute('data-source') || '';
    if (window.plausible) window.plausible(name, { props: { source: source } });
    // eslint-disable-next-line no-console
    console.log('[track]', name, source);
  });

  /* ---- tel/mailto taps also tracked ---- */
})();
