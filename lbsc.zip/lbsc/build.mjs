/* LBSC static site builder.
   Reads content fragments from src/pages/<slug>.html, wraps each in the shared
   document chrome (head, header, nav, drawer, footer) and writes <slug>.html to
   the project root. Run:  node build.mjs
*/
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CHECKLICK = 'https://lakeofbayssailingclub.checklick.com/';
const SHOPIFY = 'https://lake-of-bays-sailing-club.myshopify.com';
const RACEHUB = 'https://sites.google.com/view/lbscracing/home';

/* ---- Nav model (single source of truth) --------------------------------- */
const NAV = [
  { label: 'Home', href: 'index.html', key: 'home' },
  { label: 'Programs', key: 'programs', children: [
    { label: 'Junior Sailing (7–18)', href: 'junior-sailing.html', note: 'The learn-to-sail program' },
    { label: 'Race Teams', href: 'race-teams.html', note: 'Opti & 420 racing' },
    { label: 'Adults & Private Lessons', href: 'adults.html' },
    { label: 'Yoga on the Dock', href: 'yoga.html' },
  ]},
  { label: 'Club', key: 'club', children: [
    { label: 'Membership', href: 'membership.html' },
    { label: 'Events & Calendar', href: 'events.html' },
    { label: 'Newsletter', href: 'newsletter.html' },
    { label: 'Our Instructors', href: 'instructors.html' },
    { label: 'Our Story (1964–today)', href: 'story.html' },
    { label: 'Board & Governance', href: 'governance.html' },
  ]},
  { label: 'Support Us', key: 'support', children: [
    { label: 'Donate (Capital Campaign)', href: 'donate.html' },
    { label: 'Volunteer', href: 'volunteer.html' },
    { label: 'Sponsors', href: 'sponsors.html' },
    { label: 'Shop LBSC', href: SHOPIFY, external: true },
  ]},
];

/* ---- SVG bits ----------------------------------------------------------- */
const logo = `<img class="brand__crest" src="assets/img/logo.png" width="40" height="60" alt="Lake of Bays Sailing Club crest" decoding="async">`;

const ig = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2c2.7 0 3 0 4.1.1 1 0 1.7.2 2.3.4.6.3 1.1.6 1.6 1.1s.8 1 1.1 1.6c.2.6.4 1.3.4 2.3.1 1.1.1 1.4.1 4.1s0 3-.1 4.1c0 1-.2 1.7-.4 2.3-.3.6-.6 1.1-1.1 1.6s-1 .8-1.6 1.1c-.6.2-1.3.4-2.3.4-1.1.1-1.4.1-4.1.1s-3 0-4.1-.1c-1 0-1.7-.2-2.3-.4-.6-.3-1.1-.6-1.6-1.1s-.8-1-1.1-1.6c-.2-.6-.4-1.3-.4-2.3C2 15 2 14.7 2 12s0-3 .1-4.1c0-1 .2-1.7.4-2.3.3-.6.6-1.1 1.1-1.6s1-.8 1.6-1.1c.6-.2 1.3-.4 2.3-.4C9 2 9.3 2 12 2Zm0 5a5 5 0 100 10 5 5 0 000-10Zm0 8.2A3.2 3.2 0 1112 8.8a3.2 3.2 0 010 6.4ZM17.8 5.6a1.2 1.2 0 100 2.4 1.2 1.2 0 000-2.4Z"/></svg>`;
const fb = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 12a10 10 0 10-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 2.9h-2.4v7A10 10 0 0022 12Z"/></svg>`;
const yt = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23 7.5a3 3 0 00-2.1-2.1C19 4.9 12 4.9 12 4.9s-7 0-8.9.5A3 3 0 001 7.5C.5 9.4.5 12 .5 12s0 2.6.5 4.5a3 3 0 002.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 002.1-2.1c.5-1.9.5-4.5.5-4.5s0-2.6-.5-4.5ZM9.8 15.3V8.7l5.7 3.3-5.7 3.3Z"/></svg>`;

/* ---- Header + desktop nav + mobile drawer ------------------------------- */
function navItem(item, active) {
  if (!item.children) {
    const cur = item.key === active ? ' aria-current="page"' : '';
    return `<li class="nav-item"><a href="${item.href}"${cur}>${item.label}</a></li>`;
  }
  const menu = item.children.map(c =>
    `<a href="${c.href}"${c.external ? ' target="_blank" rel="noopener"' : ''}>${c.label}${c.note ? `<small>${c.note}</small>` : ''}</a>`
  ).join('');
  const isActive = item.key === active;
  return `<li class="nav-item">
    <button aria-expanded="false"${isActive ? ' style="color:#bfe2ee"' : ''}>${item.label} <span aria-hidden="true">▾</span></button>
    <div class="nav-menu">${menu}</div>
  </li>`;
}

function header(active) {
  const links = NAV.map(i => navItem(i, active)).join('');
  const drawerItems = NAV.map(i => {
    if (!i.children) return `<a class="drawer-link" href="${i.href}">${i.label}</a>`;
    const subs = i.children.map(c => `<a href="${c.href}"${c.external ? ' target="_blank" rel="noopener"' : ''}>${c.label}</a>`).join('');
    return `<details><summary>${i.label}</summary><div class="drawer-sub">${subs}</div></details>`;
  }).join('');
  return `<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
  <div class="wrap nav">
    <a class="brand" href="index.html">${logo}<span>Lake of Bays<br><small>Sailing Club</small><small class="brand__tagline">Since 1964</small></span></a>
    <nav class="nav-links" aria-label="Primary"><ul style="display:flex;gap:.35rem;list-style:none;margin:0;padding:0">${links}</ul>
      <a class="nav-contact" href="contact.html">Contact</a>
    </nav>
    <div class="nav-actions">
      <a class="btn btn--primary btn--sm" href="${CHECKLICK}" target="_blank" rel="noopener" data-track="register" data-source="header">Register</a>
      <button class="nav-toggle" aria-label="Open menu" aria-controls="drawer" aria-expanded="false"><span></span><span></span><span></span></button>
    </div>
  </div>
</header>
<div class="drawer" id="drawer" data-open="false">
  <div class="drawer-top">
    <a class="brand" href="index.html">${logo}<span>Lake of Bays<br><small>Sailing Club</small></span></a>
    <button class="drawer-close" aria-label="Close menu">×</button>
  </div>
  <nav aria-label="Mobile">
    ${drawerItems}
    <a class="drawer-link" href="contact.html">Contact</a>
    <a class="btn btn--primary btn--block" href="${CHECKLICK}" target="_blank" rel="noopener" data-track="register" data-source="drawer">Register for 2026</a>
  </nav>
</div>`;
}

/* ---- Footer ------------------------------------------------------------- */
function footer() {
  return `<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="brand" href="index.html">${logo}<span>Lake of Bays<br><small>Sailing Club</small></span></a>
        <p>A non-profit sailing and social club on the south shore of Lake of Bays since 1964.</p>
        <p style="margin-top:.8rem;font-size:.9375rem">1111 Glenmount Road<br>Baysville, ON P0B 1A0<br>
        <a href="tel:7057673937">705.767.3937</a> <span class="muted">(summer months only)</span></p>
        <div class="social-row">
          <a href="https://instagram.com/lakeofbayssailingclub/" target="_blank" rel="noopener" aria-label="Instagram">${ig}</a>
          <a href="https://facebook.com/LOBSailingClub/" target="_blank" rel="noopener" aria-label="Facebook">${fb}</a>
          <a href="https://youtube.com/@LakeOfBaysSailingClub" target="_blank" rel="noopener" aria-label="YouTube">${yt}</a>
        </div>
      </div>
      <div>
        <h4>Explore</h4>
        <ul>
          <li><a href="junior-sailing.html">Junior Sailing</a></li>
          <li><a href="race-teams.html">Race Teams</a></li>
          <li><a href="membership.html">Membership</a></li>
          <li><a href="events.html">Events & Calendar</a></li>
          <li><a href="instructors.html">Our Instructors</a></li>
          <li><a href="donate.html">Donate</a></li>
        </ul>
      </div>
      <div>
        <h4>Get in touch</h4>
        <ul>
          <li><a href="mailto:info@lbsc.ca">info@lbsc.ca</a><br><span class="muted" style="font-size:.85rem">General & secretary</span></li>
          <li><a href="mailto:headinstructor@lbsc.ca">headinstructor@lbsc.ca</a><br><span class="muted" style="font-size:.85rem">Lessons & rentals</span></li>
          <li><a href="mailto:racing@lbsc.ca">racing@lbsc.ca</a><br><span class="muted" style="font-size:.85rem">Race teams</span></li>
        </ul>
        <h4 style="margin-top:1.5rem">Newsletter</h4>
        <form class="subscribe" onsubmit="event.preventDefault();this.reset();alert('Thanks! We\\'ll be in touch.');" data-track="newsletter" data-source="footer">
          <input type="email" inputmode="email" autocomplete="email" placeholder="you@email.com" aria-label="Email address" required>
          <button class="btn btn--blue btn--sm" type="submit">Subscribe</button>
        </form>
      </div>
    </div>
    <div class="footer-bottom">
      <span>Non-profit since 1964 · © <span id="yr">2026</span> Lake of Bays Sailing Club</span>
      <span class="policies">
        <a href="governance.html#documents">Privacy Policy</a>
        <a href="governance.html#documents">Safe Sport Policy</a>
        <a href="governance.html#documents">Bylaws</a>
        <a href="governance.html#documents">Financial Statements</a>
      </span>
    </div>
  </div>
</footer>`;
}

/* ---- Document wrapper --------------------------------------------------- */
function doc({ slug, title, desc, active, jsonld = '', sticky = '', body }) {
  const canonical = `https://www.lbsc.ca/${slug === 'index' ? '' : slug + '.html'}`;
  const ld = jsonld ? `\n<script type="application/ld+json">${jsonld}</script>` : '';
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<meta name="description" content="${desc}">
<link rel="canonical" href="${canonical}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${desc}">
<meta property="og:type" content="website">
<meta name="theme-color" content="#0E3A4F">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/tokens.css">
<link rel="stylesheet" href="assets/css/main.css">${ld}
</head>
<body>
${header(active)}
<main id="main">
${body}
</main>
${footer()}
${sticky}
<script src="assets/js/app.js" defer></script>
<script>document.getElementById('yr').textContent=new Date().getFullYear();</script>
</body>
</html>`;
}

/* ---- Page manifest ------------------------------------------------------ */
const stickyBar = `<div class="sticky-cta" data-show="false">
  <span class="note">Members & non-members welcome</span>
  <a class="btn btn--primary btn--block" href="${CHECKLICK}" target="_blank" rel="noopener" data-track="register" data-source="sticky">Register for Summer 2026</a>
</div>`;

const PAGES = [
  { slug: 'index', active: 'home', sticky: stickyBar,
    title: 'Lake of Bays Sailing Club | Junior Sailing Camp in Baysville, Muskoka',
    desc: 'Learn-to-sail programs for kids and teens 7–18 on Lake of Bays. Sail Canada certified instructors, weekly sessions all summer. Family-run since 1964. Register for 2026.',
    jsonld: JSON.stringify({
      '@context':'https://schema.org','@type':'SportsClub',name:'Lake of Bays Sailing Club',
      url:'https://www.lbsc.ca/', telephone:'+1-705-767-3937', foundingDate:'1964',
      sameAs:['https://instagram.com/lakeofbayssailingclub/','https://facebook.com/LOBSailingClub/','https://youtube.com/@LakeOfBaysSailingClub'],
      address:{'@type':'PostalAddress',streetAddress:'1111 Glenmount Road',addressLocality:'Baysville',addressRegion:'ON',postalCode:'P0B 1A0',addressCountry:'CA'},
      geo:{'@type':'GeoCoordinates',latitude:45.15,longitude:-79.10}
    }) },
  { slug: 'junior-sailing', active: 'programs', sticky: stickyBar,
    title: 'Junior Sailing Programs (Ages 7–18) | Lake of Bays Sailing Club',
    desc: 'CANSail-certified learn-to-sail programs for kids and teens on Lake of Bays. Weekly sessions, half or full day. Members and non-members welcome.' },
  { slug: 'race-teams', active: 'programs',
    title: 'Race Teams: Opti &amp; 420 Racing | Lake of Bays Sailing Club',
    desc: 'Junior and senior race teams on Lake of Bays for CANSail 4–6 and Optimist racers. Regatta season, contracts, and the full race team hub.' },
  { slug: 'adults', active: 'programs',
    title: 'Adult & Private Sailing Lessons | Lake of Bays Sailing Club',
    desc: 'Private sailing lessons, boat rentals and adult instruction on Lake of Bays, arranged through our Head Instructor.' },
  { slug: 'yoga', active: 'programs',
    title: 'Yoga on the Dock | Lake of Bays Sailing Club',
    desc: 'Saturday morning and sunset yoga on the dock at Lake of Bays. $20 members, $25 non-members. Bring a mat, water and a bathing suit.' },
  { slug: 'membership', active: 'club',
    title: 'Membership | Lake of Bays Sailing Club',
    desc: 'Family Sailing Membership ($200/yr) and Social Membership ($50/yr) at Lake of Bays Sailing Club. Join a family-run Muskoka club since 1964.' },
  { slug: 'events', active: 'club',
    title: 'Events & Calendar | Lake of Bays Sailing Club',
    desc: 'Activity Nights, Awards Nights, regattas and socials all summer at Lake of Bays Sailing Club. See the season at a glance.' },
  { slug: 'instructors', active: 'club',
    title: 'Our Instructors | Lake of Bays Sailing Club',
    desc: 'Meet the Sail Canada certified instructors at Lake of Bays Sailing Club. Many are alumni back for their 8th, 10th or 14th summer.' },
  { slug: 'story', active: 'club',
    title: 'Our Story (1964–today) | Lake of Bays Sailing Club',
    desc: 'From two rooms at Bigwin Inn in 1964 to the heart of summer on Lake of Bays. The story of the Lake of Bays Sailing Club.' },
  { slug: 'governance', active: 'club',
    title: 'Board & Governance | Lake of Bays Sailing Club',
    desc: 'The board of directors, committees, bylaws and policies of the Lake of Bays Sailing Club, plus 60 years of past directors.' },
  { slug: 'donate', active: 'support',
    title: 'Donate to the Capital Campaign | Lake of Bays Sailing Club',
    desc: 'Support the dock, the fleet and the clubhouse. Donations through Sail Canada to the LBSC Capital Campaign are tax-receipted.' },
  { slug: 'volunteer', active: 'support',
    title: 'Volunteer | Lake of Bays Sailing Club',
    desc: 'Every family helps with at least one event. Pick your spot, and high school students earn community service hours.' },
  { slug: 'sponsors', active: 'support',
    title: 'Sponsors | Lake of Bays Sailing Club',
    desc: 'Thank you to the families and Friends of LBSC supporting the Capital Campaign at the Lake of Bays Sailing Club.' },
  { slug: 'contact', active: 'contact',
    title: 'Contact | Lake of Bays Sailing Club',
    desc: 'Reach the Lake of Bays Sailing Club in Baysville, Muskoka. General, head instructor and racing emails, phone, and directions.' },
  { slug: 'newsletter', active: 'club',
    title: 'Newsletter Archive | Lake of Bays Sailing Club',
    desc: 'Read the weekly newsletters from the Lake of Bays Sailing Club and subscribe for a heads-up when registration opens.' },
  { slug: 'gallery', active: 'club',
    title: 'Photo Gallery | Lake of Bays Sailing Club',
    desc: 'Photos from the water, the dock and Activity Nights at the Lake of Bays Sailing Club.' },
];

/* ---- Build -------------------------------------------------------------- */
let built = 0;
for (const p of PAGES) {
  const fragPath = join(__dirname, 'src', 'pages', `${p.slug}.html`);
  let body;
  try { body = readFileSync(fragPath, 'utf8'); }
  catch { console.warn(`! missing fragment: src/pages/${p.slug}.html (skipped)`); continue; }
  const html = doc({ ...p, body });
  writeFileSync(join(__dirname, `${p.slug}.html`), html);
  built++;
}
console.log(`Built ${built}/${PAGES.length} pages.`);
